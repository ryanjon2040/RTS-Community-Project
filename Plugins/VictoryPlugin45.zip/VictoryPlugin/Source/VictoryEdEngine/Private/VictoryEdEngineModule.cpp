
#include "VictoryEdEnginePCH.h"
//#include "VictoryEdEngine.generated.inl"

DEFINE_LOG_CATEGORY(Victory)

IMPLEMENT_MODULE(FDefaultModuleImpl, VictoryEdEngine);
