// Copyright 1998-2013 Epic Games, Inc. All Rights Reserved.

#include "VictoryBPLibraryPrivatePCH.h"
//#include "VictoryBPLibrary.generated.inl"

//DEFINE_LOG_CATEGORY(Victory)

IMPLEMENT_MODULE(FDefaultGameModuleImpl, VictoryBPLibrary);