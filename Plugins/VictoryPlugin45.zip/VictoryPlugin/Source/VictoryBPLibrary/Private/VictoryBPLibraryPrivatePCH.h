// Copyright 1998-2013 Epic Games, Inc. All Rights Reserved.

#pragma once

#include "Engine.h"
#include "VictoryBPLibraryClasses.h"

//DECLARE_LOG_CATEGORY_EXTERN(Victory, Log, All);
